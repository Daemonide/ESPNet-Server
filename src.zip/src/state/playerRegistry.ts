import type { Player } from "../types.js";

export class PlayerRegistry {
  private players = new Map<string, Player>();

  list(): Player[] {
    return Array.from(this.players.values());
  }

  get(id: string): Player | null {
    return this.players.get(id) ?? null;
  }

  add(
    name: string,
    team: Player["team"] = null,
    controllerMac: string | null = null,
  ): Player {
    const player: Player = {
      id: crypto.randomUUID(),
      name,
      team,
      controllerMac,
      available: true,
      createdAt: Date.now(),
    };

    this.players.set(player.id, player);

    return player;
  }

  update(
    id: string,
    changes: Partial<
      Pick<Player, "name" | "team" | "controllerMac" | "available">
    >,
  ): Player | null {
    const player = this.players.get(id);

    if (!player) {
      return null;
    }

    Object.assign(player, changes);

    return player;
  }

  remove(id: string): boolean {
    return this.players.delete(id);
  }

  setAvailability(
    id: string,
    available: boolean,
  ): Player | null {
    return this.update(id, { available });
  }

  availablePlayers(): Player[] {
    return this.list().filter(
      (player) => player.available,
    );
  }
}
import { Router } from "express";
import { z } from "zod";

import type { Engine } from "../../engine.js";

const createPlayerSchema = z.object({
  name: z.string().min(1).max(64),
  team: z.enum(["red", "blue"]).nullable().optional(),
  controllerMac: z.string().nullable().optional(),
});

const updatePlayerSchema = z.object({
  name: z.string().min(1).max(64).optional(),
  team: z.enum(["red", "blue"]).nullable().optional(),
  controllerMac: z.string().nullable().optional(),
  available: z.boolean().optional(),
});

export function playersRouter(engine: Engine): Router {
  const router = Router();

  // Get all players
  router.get("/", (_req, res) => {
    res.json({
      players: engine.players.list(),
    });
  });

  // Get one player
  router.get("/:id", (req, res) => {
    const player = engine.players.get(req.params.id);

    if (!player) {
      return res.status(404).json({
        success: false,
        error: "player not found",
      });
    }

    res.json({
      player,
    });
  });

  // Add a new player
  router.post("/", (req, res) => {
    const parsed = createPlayerSchema.safeParse(
      req.body,
    );

    if (!parsed.success) {
      return res.status(400).json({
        success: false,
        error: "invalid player data",
      });
    }

    const player = engine.players.add(
      parsed.data.name,
      parsed.data.team ?? null,
      parsed.data.controllerMac ?? null,
    );

    res.status(201).json({
      success: true,
      player,
    });
  });

  // Update player
  router.put("/:id", (req, res) => {
    const parsed = updatePlayerSchema.safeParse(
      req.body,
    );

    if (!parsed.success) {
      return res.status(400).json({
        success: false,
        error: "invalid player data",
      });
    }

    const player = engine.players.update(
      req.params.id,
      parsed.data,
    );

    if (!player) {
      return res.status(404).json({
        success: false,
        error: "player not found",
      });
    }

    res.json({
      success: true,
      player,
    });
  });

  // Change availability
  router.put("/:id/availability", (req, res) => {
    const schema = z.object({
      available: z.boolean(),
    });

    const parsed = schema.safeParse(req.body);

    if (!parsed.success) {
      return res.status(400).json({
        success: false,
        error: "available must be boolean",
      });
    }

    const player = engine.players.setAvailability(
      req.params.id,
      parsed.data.available,
    );

    if (!player) {
      return res.status(404).json({
        success: false,
        error: "player not found",
      });
    }

    res.json({
      success: true,
      player,
    });
  });

  // Delete player
  router.delete("/:id", (req, res) => {
    const ok = engine.players.remove(
      req.params.id,
    );

    res.status(ok ? 200 : 404).json({
      success: ok,
    });
  });

  return router;
}